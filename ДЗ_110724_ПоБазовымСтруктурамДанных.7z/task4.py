# 4th program
print(int(13.42)==int(42.13*100%100)or 13.42*100%100==int(42.13))

